-- 6. Inner Join: Students with their enrolled courses
SELECT s.first_name, s.last_name, c.course_name
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
JOIN courses c ON e.course_id = c.course_id;

-- 7. Left Join: All teachers (even those without courses)
SELECT t.first_name, t.last_name, c.course_name
FROM teachers t
LEFT JOIN courses c ON t.teacher_id = c.teacher_id;

-- 8. Group By: Count students per department
SELECT d.department_name, COUNT(s.student_id) AS student_count
FROM departments d
JOIN courses c ON d.department_id = c.department_id
JOIN enrollments e ON c.course_id = e.course_id
JOIN students s ON e.student_id = s.student_id
GROUP BY d.department_name;

-- 9. Having: Departments with avg GPA > 3.5
SELECT d.department_name, AVG(s.gpa) AS avg_gpa
FROM departments d
JOIN courses c ON d.department_id = c.department_id
JOIN enrollments e ON c.course_id = e.course_id
JOIN students s ON e.student_id = s.student_id
GROUP BY d.department_name
HAVING avg_gpa > 3.5;

-- 10. Subquery: Students with above-average GPA
SELECT first_name, last_name, gpa
FROM students
WHERE gpa > (SELECT AVG(gpa) FROM students);