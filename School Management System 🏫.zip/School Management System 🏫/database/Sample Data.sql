-- Insert sample departments
INSERT INTO departments (department_name, location, budget) VALUES 
('Computer Science', 'Building A', 500000),
('Mathematics', 'Building B', 300000),
('Physics', 'Building C', 400000);

-- Insert sample teachers
INSERT INTO teachers (first_name, last_name, email, hire_date, department_id, salary) VALUES
('John', 'Smith', 'john.smith@school.edu', '2015-08-15', 1, 75000),
('Emily', 'Johnson', 'emily.johnson@school.edu', '2018-03-22', 2, 68000),
('Michael', 'Williams', 'michael.williams@school.edu', '2016-09-01', 3, 72000);

-- Insert sample students
INSERT INTO students (first_name, last_name, email, enrollment_date, date_of_birth, gpa) VALUES
('Alice', 'Brown', 'alice.brown@student.edu', '2023-09-05', '2005-03-15', 3.75),
('Bob', 'Davis', 'bob.davis@student.edu', '2023-09-05', '2005-07-22', 3.92),
('Charlie', 'Wilson', 'charlie.wilson@student.edu', '2023-09-05', '2004-11-30', 3.45);

-- Insert sample courses
INSERT INTO courses (course_name, course_code, credits, department_id, teacher_id) VALUES
('Introduction to Programming', 'CS101', 4, 1, 1),
('Data Structures', 'CS201', 4, 1, 1),
('Calculus I', 'MATH101', 3, 2, 2),
('Quantum Physics', 'PHYS301', 4, 3, 3);

-- Insert class schedules
INSERT INTO class_schedule (course_id, day_of_week, start_time, end_time, room_number) VALUES
(1, 'Monday', '09:00:00', '10:30:00', 'A101'),
(1, 'Wednesday', '09:00:00', '10:30:00', 'A101'),
(2, 'Tuesday', '13:00:00', '14:30:00', 'B205'),
(3, 'Thursday', '11:00:00', '12:30:00', 'C102');

-- Insert enrollments
INSERT INTO enrollments (student_id, course_id, grade, status) VALUES
(1, 1, 'A', 'Active'),
(1, 3, 'B+', 'Active'),
(2, 1, 'A-', 'Active'),
(3, 3, 'C', 'Active');

-- Insert attendance records
INSERT INTO attendance (enrollment_id, date, status) VALUES
(1, '2023-10-02', 'Present'),
(1, '2023-10-04', 'Late'),
(3, '2023-10-03', 'Present'),
(4, '2023-10-05', 'Absent');

-- Insert prerequisites
INSERT INTO prerequisites (course_id, prerequisite_id) VALUES
(2, 1), -- Data Structures requires Intro to Programming
(4, 3); -- Quantum Physics requires Calculus I