-- 11. Complex Join: Student schedules
SELECT s.first_name, s.last_name, c.course_name, 
       cs.day_of_week, cs.start_time, cs.end_time, cs.room_number
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
JOIN courses c ON e.course_id = c.course_id
JOIN class_schedule cs ON c.course_id = cs.course_id
ORDER BY s.last_name, cs.day_of_week, cs.start_time;

-- 12. Union: Combine student and teacher emails
SELECT first_name, last_name, email, 'Student' AS role FROM students
UNION
SELECT first_name, last_name, email, 'Teacher' AS role FROM teachers;

-- 13. Window Function: Rank students by GPA
SELECT first_name, last_name, gpa,
       RANK() OVER (ORDER BY gpa DESC) AS gpa_rank
FROM students;

-- 14. Case Statement: Grade classification
SELECT s.first_name, s.last_name, c.course_name, e.grade,
       CASE 
           WHEN e.grade = 'A' THEN 'Excellent'
           WHEN e.grade = 'B' THEN 'Good'
           WHEN e.grade = 'C' THEN 'Average'
           ELSE 'Needs Improvement'
       END AS performance
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
JOIN courses c ON e.course_id = c.course_id;

-- 15. Stored Procedure: Calculate GPA
DELIMITER //
CREATE PROCEDURE CalculateStudentGPA(IN student_id_param INT)
BEGIN
    DECLARE total_points DECIMAL(10,2);
    DECLARE total_credits INT;
    
    SELECT SUM(
        CASE 
            WHEN grade = 'A' THEN 4 * credits
            WHEN grade = 'B' THEN 3 * credits
            WHEN grade = 'C' THEN 2 * credits
            WHEN grade = 'D' THEN 1 * credits
            ELSE 0
        END
    ) INTO total_points
    FROM enrollments e
    JOIN courses c ON e.course_id = c.course_id
    WHERE e.student_id = student_id_param AND e.grade IS NOT NULL;
    
    SELECT SUM(credits) INTO total_credits
    FROM enrollments e
    JOIN courses c ON e.course_id = c.course_id
    WHERE e.student_id = student_id_param AND e.grade IS NOT NULL;
    
    IF total_credits > 0 THEN
        UPDATE students 
        SET gpa = ROUND(total_points / total_credits, 2)
        WHERE student_id = student_id_param;
    END IF;
    
    SELECT first_name, last_name, gpa 
    FROM students 
    WHERE student_id = student_id_param;
END //
DELIMITER ;

-- Call the procedure
CALL CalculateStudentGPA(1);