# School Management System Database

## Overview
A relational database for tracking students, teachers, courses, and academic records.

## Features
- ✅ Normalized schema (3NF)
- ✅ GPA constraints
- ✅ Prerequisite checks
- ✅ 15+ SQL queries

## Setup
1. Run `school_management_system.sql` to create tables.
2. Execute `sample_data.sql` to populate test data.
3. Use `queries.sql` for examples.

## ERD
![ERD Diagram](erd.png)

## Testing
- All queries validated in MySQL 8.0.
- Constraints tested for data integrity.
## Database Design
- Normalized to 3NF
- 8 core tables
- ACID-compliant transactions

## Setup Instructions
1. Run schema script:
   ```bash
   mysql -u username -p < database/01_schema.sql