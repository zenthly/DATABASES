-- 1. Select all students with GPA > 3.5
SELECT * FROM students WHERE gpa > 3.5;

-- 2. Insert a new teacher
INSERT INTO teachers (first_name, last_name, email, department_id, salary) 
VALUES ('Sarah', 'Miller', 'sarah.miller@school.edu', 2, 70000);

-- 3. Update a student's GPA
UPDATE students SET gpa = 3.8 WHERE student_id = 3;

-- 4. Delete a course
DELETE FROM courses WHERE course_id = 4;

-- 5. List top 3 students by GPA
SELECT * FROM students ORDER BY gpa DESC LIMIT 3;